CREATE TABLE posts (
    id SERIAL PRIMARY KEY,
    link CHAR(36) NOT NULL,
    title VARCHAR(255) NOT NULL,
    preview VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    timestamp TIMESTAMP NOT NULL
);

-- INSERT INTO posts (link, title, preview, content, timestamp) VALUES
-- ('posts/post/?id=1', 'Первый пост', 'Это превью первого поста', 'Содержимое первого поста.', '2024-10-13 10:00:00'),
-- ('posts/post/?id=2', 'Второй пост', 'Краткое содержание второго поста', 'Содержимое второго поста.', '2024-10-13 11:00:00'),
-- ('posts/post/?id=3', 'Третий пост', 'Обзор третьего поста', 'Содержимое третьего поста.', '2024-10-13 12:00:00'),
-- ('posts/post/?id=4', 'Четвертый пост', 'Это превью четвертого поста', 'Содержимое четвертого поста.', '2024-10-13 10:00:00');


-- SELECT * FROM posts

-- DROP TABLE posts